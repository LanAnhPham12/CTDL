package Week_6;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class MyArrayList<E> {
	public static final int DEFAULT_CAPACITY = 10;
	private E[] elements;
	private int size;

	public MyArrayList() {
		this.elements = (E[]) new Object[DEFAULT_CAPACITY];
	}

	public MyArrayList(int capacity) {
		this.elements = (E[]) new Object[capacity];
	}

//creates an array of double size
	public void growSize() {
		// creates an array double size
		if (size == elements.length) {
			E[] newElements = (E[]) new Object[elements.length * 2];
			// copy
			System.arraycopy(elements, 0, newElements, 0, elements.length);
			elements = newElements;
		}
	}

//returns the number of elements in this list
	public int size() {
		return this.size;

	}

//return whether the list is empty
	public boolean isEmpty() {
		if (size == 0) {
			return true;
		}
		return false;
	}

//used to append the specified element at the end of a list
	public boolean add(E e) {
		if (size == elements.length) {
			growSize();
			elements[size++] = e;
		}
		return true;
	}

//return (but dose not remove) the element at index i
	public E get(int i) throws IndexOutOfBoundsException {
		if (i < 0 || size <= i) {
			throw new IndexOutOfBoundsException("IndexOutOFBoundsException");
		}
		return elements[i];
	}

	public E set(int i, E e) throws IndexOutOfBoundsException {
		if (i < 0 || size <= i) {
			throw new IndexOutOfBoundsException("IndexOutOfBoundsException");
		}
		E replacedElement = elements[i];
		elements[i] = e;
		return replacedElement;
	}

	public void add(int i, E e) throws IndexOutOfBoundsException {
		if (i < 0 || i > size()) {
			throw new IndexOutOfBoundsException("Invalid index: " + i);
		}

		// Make space for the new element.
		if (i >= size()) {
			// Add the new element at the end of the list.
			elements[size()] = e;
		} else {
			// Shift the elements at and after index i to the right.
			for (int j = size() - 1; j >= i; j--) {
				elements[j + 1] = elements[j];
			}

			// Insert the new element at index i.
			elements[i] = e;
		}

		// Increment the size of the list.
		size++;
	}

	public E remove(int i) throws IndexOutOfBoundsException {
		if (i < 0 || i >= size()) {
			throw new IndexOutOfBoundsException("Invalid index: " + i);
		}

		// Get the element to be removed.
		E element = elements[i];

		// Shift the elements at and after index i to the left.
		for (int j = i; j < size() - 1; j++) {
			elements[j] = elements[j + 1];
		}

		// Decrement the size of the list.
		size--;

		return element;
	}

	public void clear() {
		size = 0;
		elements = (E[]) new Object[DEFAULT_CAPACITY];
	}

	public int lastIndexOf(E e) {
		int re = -1;
		for (int i = 0; i < size; i++) {
			if (elements[i].equals(e))
				re = i;
		}
		return re;
	}

	// It is used to return an array containing all of the
	// elements in this list in the correct order.
	public E[] toArray() {
		E[] array = new E[size];
		System.arraycopy(elements, 0, array, 0, size);
		return array;
	}

	// It is used to return a shallow copy of an ArrayList.
	public MyArrayList<E> clone() {
		MyArrayList<E> newList = new MyArrayList<>();
		newList.elements = Arrays.copyOf(elements, size);
		newList.size = size;
		return newList;
	}

	// It returns true if the list contains the specified
	// element
	public boolean contains(E o) {
		for (int i = 0; i < size; i++) {
			if (o == elements[i] || o.equals(elements[i])) {
				return true;
			}
		}
		return false;
	}

	// It is used to return the index in this list of the
	// first occurrence of the specified element, or -1 if the
	// List does not contain this element.
	public int indexOf(E o) {
		for (int i = 0; i < size; i++) {
			if (o == elements[i] || o.equals(elements[i])) {
				return i;
			}
		}
		return -1;
	}

	// It is used to remove the first occurrence of the
	// specified element.
	public boolean remove(E e) {
		int index = indexOf(e);
		if (index == -1) {
			return false;
		}

		remove(index);
		return true;
	}

	public void sort(Comparator<E> comp) {
		Arrays.sort(elements, 0, size, comp);
	}
//

	public static void main(String[] args) {

		ArrayList<Integer> myArr = new ArrayList<>();
		myArr.add(1);
		myArr.add(2);
		myArr.add(3);
		myArr.add(4);
		myArr.add(5);
	}
}
