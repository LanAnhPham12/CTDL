package Week_6;

public class LinkedList {
	public class Node<E> {
		private E data;
		private Node<E> next;

		public Node(E data) {
			this.data = data;
		}

		public Node(E data, Node<E> next) {
			this.data = data;
			this.next = next;
		}

		public E getData() {
			return data;
		}

		public void setData(E data) {
			this.data = data;
		}

		public Node<E> getNext() {
			return next;
		}

		public void setNext(Node<E> next) {
			this.next = next;
		}
	}

	public class SinglyLinkedList<E> {
		private Node<E> head = null;
		private Node<E> tail = null;
		private int size;

		public SinglyLinkedList() {
			super();
		}

		// Returns the number of elements in the list.
		public int size() {
			return size;
		}

		// Returns true if the list is empty, and false
		// otherwise.
		public boolean isEmpty() {
			return size == 0;
		}

		// Returns (but does not remove) the first element in
		// the list.
		public E first() {
			if (head == null) {
				return null;
			} else {
				return head.getData();
			}
		}

		// Returns (but does not remove) the last element in
		// the list.
		public E last() {
			if (tail == null) {
				return null;
			} else {
				return tail.getData();
			}
		}

		// Adds a new element to the front of the list.
		public void addFirst(E e) {
			Node<E> newNode = new Node<>(e);
			if (head == null) {
				head = tail = newNode;
			} else {
				newNode.setNext(head);
				head = newNode;
			}
			size++;
		}

		// Adds a new element to the end of the list.
		public void addLast(E e) {
			Node<E> newNode = new Node<>(e);
			if (head == null) {
				head = tail = newNode;
			} else {
				tail.setNext(newNode);
				tail = newNode;
			}
			size++;
		}

		// Removes and returns the first element of the list.
		public E removeFirst() {
			if (head == null) {
				return null;
			} else {
				Node<E> oldHead = head;
				head = head.getNext();
				size--;
				return oldHead.getData();
			}
		}

		// Removes and returns the last element of the list.
		public E removeLast() {
			if (head == null) {
				return null;
			} else {
				Node<E> oldTail = tail;
				if (head == tail) {
					head = tail = null;
				} else {
					Node<E> current = head;
					while (current.getNext() != tail) {
						current = current.getNext();
					}
					current.setNext(null);
					tail = current;
				}
				size--;
				return oldTail.getData();
			}
		}
	}

	    public static void main(String[] args) {
	        // Tạo một danh sách liên kết đơn
	        SinglyLinkedList<Integer> list = new SinglyLinkedList<>();

	        // Thêm các phần tử vào danh sách liên kết đơn
	        list.addFirst(1);
	        list.addLast(2);
	        list.addLast(3);

	        // In ra danh sách liên kết đơn
	        System.out.println("Danh sách liên kết đơn:");
	      //  list.forEach(System.out::println);

	        // Kiểm tra danh sách liên kết đơn có rỗng hay không
	        System.out.println("Danh sách liên kết đơn có rỗng không? " + list.isEmpty());

	        // Lấy phần tử đầu tiên trong danh sách liên kết đơn
	        System.out.println("Phần tử đầu tiên trong danh sách liên kết đơn: " + list.first());

	        // Lấy phần tử cuối cùng trong danh sách liên kết đơn
	        System.out.println("Phần tử cuối cùng trong danh sách liên kết đơn: " + list.last());

	        // Xóa phần tử đầu tiên trong danh sách liên kết đơn
	        list.removeFirst();

	        // Xóa phần tử cuối cùng trong danh sách liên kết đơn
	        list.removeLast();

	        // In ra danh sách liên kết đơn sau khi xóa
	        System.out.println("Danh sách liên kết đơn sau khi xóa:");
	        //list.forEach(System.out::println);
	    }
	}

}
