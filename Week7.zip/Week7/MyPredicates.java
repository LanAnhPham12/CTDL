package  Week7;


import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

public class MyPredicates {
	// Remove every object, obj, from coll for which p.test(obj)
	// is true. (This does the same thing as coll.removeIf(p).)
	public static <T> void remove(Collection<T> coll, Predicate<T> p) {
	    // Iterate over the collection and remove any object that satisfies the predicate.
	    for (Iterator<T> it = coll.iterator(); it.hasNext();) {
	        T obj = it.next();
	        if (p.test(obj)) {
	            it.remove();
	        }
	    }
	}

	public static <T> void retain(Collection<T> coll, Predicate<T> p) {
	    // Iterate over the collection and remove any object that does not satisfy the predicate.
	    for (Iterator<T> it = coll.iterator(); it.hasNext();) {
	        T obj = it.next();
	        if (!p.test(obj)) {
	            it.remove();
	        }
	    }
	}

	public static <T> Set<T> collect(Collection<T> coll, Predicate<T> p) {
	    // Create a set to store the filtered elements.
	    Set<T> filteredElements = new HashSet<>();

	    // Iterate over the collection and add any object that satisfies the predicate to the set.
	    for (T obj : coll) {
	        if (p.test(obj)) {
	            filteredElements.add(obj);
	        }
	    }

	    // Return the set of filtered elements.
	    return filteredElements;
	}

	public static <T> int find(Collection<T> coll, Predicate<T> p) {
	    // Iterate over the collection and return the index of the first object that satisfies the predicate, if any.
	    for (int i = 0; i < coll.size(); i++) {
	        T obj = ((Object) coll).get(i);
	        if (p.test(obj)) {
	            return i;
	        }
	    }

	    // If no object satisfies the predicate, return -1.
	    return -1;
	}
	public static void main(String[] args) {
		// Remove all even numbers from a list.
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		MyPredicates.remove(numbers, new Predicate<Integer>() {
		    @Override
		    public boolean test(Integer number) {
		        return number % 2 == 0;
		    }
		});

		// Print out the remaining numbers.
		System.out.println(numbers);

		// Retain only the words that start with the letter 'A' from a set.
		Set<String> words = new HashSet<>(Arrays.asList("apple", "banana", "cat", "dog", "elephant"));
		MyPredicates.retain(words, new Predicate<String>() {
		    @Override
		    public boolean test(String word) {
		        return word.startsWith("A");
		    }
		});

		// Print out the remaining words.
		System.out.println(words);

		// Collect all the unique even numbers from a list into a set.
		Set<Integer> evenNumbers = MyPredicates.collect(numbers, new Predicate<Integer>() {
		    @Override
		    public boolean test(Integer number) {
		        return number % 2 == 0;
		    }
		});

		// Print out the set of even numbers.
		System.out.println(evenNumbers);

		// Find the index of the first even number in a list, if any.
		int index = MyPredicates.find(numbers, new Predicate<Integer>() {
		    @Override
		    public boolean test(Integer number) {
		        return number % 2 == 0;
		    }
		});

		// Print out the index of the even number, or -1 if there is no even number in the list.
		System.out.println(index);

	}
}
