package Week7;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class MyWordCount {
	// public static final String fileName = "data/hamlet.txt";
	public static final String fileName = "data/fit.txt";

	private List<String> words = new ArrayList<>();

	public MyWordCount() {
		try {
			this.words.addAll(Utils.loadWords(fileName));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	// Prints out the number of times each unique token appears in the file
	// data/hamlet.txt (or fit.txt)
	// In this method, we do not consider the order of tokens.
	public List<WordCount> getWordCounts() {
		// TODO
		Set<String> wordSet = new HashSet<String>();
		for (String word : words)
			wordSet.add(word);
		List<WordCount> wordCounts = new ArrayList<>();
		for (String word : wordSet) {
			int count = Collections.frequency(words, word);
			wordCounts.add(new WordCount(word, count));
		}

		return wordCounts;
	}

// Returns the words in the text file, duplicated words appear once in the
	// result
	public Set<String> getDistinctWords() {
		Set<String> uniqueWord = new HashSet<>();
		for (String word : words) {
			if (Collections.frequency(words, word) == 1) {
				uniqueWord.add(word);
			}
		}
		return uniqueWord;
	}

	// Prints out the number of times each unique token appears in the file
	// data/hamlet.txt (or fit.txt) according ascending order of tokens
	// Example: An - 3, Bug - 10, ...
	public Set<WordCount> printWordCounts() {
		// TODO
		Set<WordCount> re = new TreeSet<WordCount>(new Comparator<WordCount>() {

			@Override
			public int compare(WordCount o1, WordCount o2) {
				// TODO Auto-generated method stub
				int re = o1.getCount() - o2.getCount();
				if (re == 0) {
					return o1.getWord().compareTo(o2.getWord());
				}
				return re;
				// return o1.getWord().compareTo(o2.getWord());
			}

		});
		re.addAll(this.getWordCounts());
		return re;

	}

	public Set<WordCount> exportWordCounts() {
		// Create a sorted set to store the word counts in ascending order of tokens.
		Set<WordCount> wordCounts = new TreeSet<>(new Comparator<WordCount>() {
			@Override
			public int compare(WordCount o1, WordCount o2) {
				// Compare the two words.
				return o1.getWord().compareTo(o2.getWord());
			}
		});

		// Add all the word counts to the sorted set.
		wordCounts.addAll(this.getWordCounts());

		// Print out the word counts.
		for (WordCount wordCount : wordCounts) {
			System.out.println(wordCount.getWord() + " - " + wordCount.getCount());
		}

		// Return the sorted set of word counts.
		return wordCounts;
	}

	// Prints out the number of times each unique token appears in the file
	// data/hamlet.txt (or fit.txt) according descending order of occurences
	// Example: Bug - 10, An - 3, Nam - 2.
	public Set<WordCount> exportWordCountsByOccurence() {
		// Create a sorted set to store the word counts in descending order of
		// occurrences.
		Set<WordCount> wordCounts = new TreeSet<>(new Comparator<WordCount>() {
			@Override
			public int compare(WordCount o1, WordCount o2) {
				// Compare the two counts in descending order.
				return o2.getCount() - o1.getCount();
			}
		});

		// Add all the word counts to the sorted set.
		wordCounts.addAll(this.getWordCounts());

		// Print out the word counts.
		for (WordCount wordCount : wordCounts) {
			System.out.println(wordCount.getWord() + " - " + wordCount.getCount());
		}

		// Return the sorted set of word counts.
		return wordCounts;
	}

	// delete words begining with the given pattern (i.e., delete words begin with
	// 'A' letter
	public Set<String> filterWords(String pattern) {
		// Create a set to store the filtered words.
		Set<String> filteredWords = new HashSet<>();

		// Iterate over the words in the text file.
		for (String word : words) {
			// If the word does not begin with the given pattern, add it to the set of
			// filtered words.
			if (!word.startsWith(pattern)) {
				filteredWords.add(word);
			}
		}

		// Return the set of filtered words.
		return filteredWords;
	}

	public static void main(String[] args) {
		MyWordCount myWordCount = new MyWordCount();

		// Test the getWordCounts() method.
		List<WordCount> wordCounts = myWordCount.getWordCounts();
		System.out.println("Number of unique words: " + wordCounts.size());

		// Test the getDistinctWords() method.
		Set<String> distinctWords = myWordCount.getDistinctWords();
		System.out.println("Number of distinct words: " + distinctWords.size());

		// Test the printWordCounts() method.
		myWordCount.printWordCounts();

		// Test the exportWordCountsByOccurence() method.
		myWordCount.exportWordCountsByOccurence();

		// Test the filterWords() method.
		Set<String> filteredWords = myWordCount.filterWords("A");
		System.out.println("Number of words that do not begin with A: " + filteredWords.size());
	}

}
