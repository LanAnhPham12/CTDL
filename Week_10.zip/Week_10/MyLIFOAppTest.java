package Week_10;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class MyLIFOAppTest {


    // Test for the `reverse` method
    @Test
    public void testReverse() {
        Integer[] array = {1, 2, 3, 4, 5};
        MyLIFO_App.reverse(array);

        assertEquals(5, array.length);
        assertArrayEquals(new Integer[]{5, 4, 3, 2, 1}, array);
    }

    // Test for the `isCorrect` method
    @Test
    public void testIsCorrect() {
        assertTrue(MyLIFO_App.isCorrect("(())[]{(())}"));
        assertFalse(MyLIFO_App.isCorrect("){[]}()"));
    }

    // Test for the `inSentBlanks` method
    @Test
    public void testInSentBlanks() {
        assertEquals("51 + (54 *(3+2))", MyLIFO_App.inSentBlanks("51+(54*(3+2))"));
    }

    // Test for the `evaluateExpression` method (assuming it's implemented)
    @Test
    public void testEvaluateExpression() {
        assertEquals(321, MyLIFO_App.inSentBlanks("51+(54*(3+2))"));
    }
}


