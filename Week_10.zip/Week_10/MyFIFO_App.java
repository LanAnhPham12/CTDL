package Week_10;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class MyFIFO_App {

	    // Method stutter that accepts a queue of integers as a parameter and replaces
	    // every element of the queue with two copies of that element
	    public static void stutter(Queue<Integer> input) {
	        Queue<Integer> tempQueue = new LinkedList<>(); // Create a temporary queue

	        while (!input.isEmpty()) { // Iterate through the input queue
	            int element = input.poll(); // Remove an element from the input queue
	            tempQueue.add(element); // Add the element to the temporary queue
	            tempQueue.add(element); // Add another copy of the element to the temporary queue
	        }

	        input.clear(); // Clear the input queue
	        input.addAll(tempQueue); // Add all elements from the temporary queue to the input queue
	    }

	    // Method mirror that accepts a queue of strings as a parameter and appends the
	    // queue's contents to itself in reverse order
	    public static void mirror(Queue<String> input) {
	        Stack<String> tempStack = new Stack<>(); // Create a temporary stack

	        while (!input.isEmpty()) { // Iterate through the input queue
	            tempStack.push(input.poll()); // Push an element from the input queue onto the temp stack
	        }

	        while (!tempStack.isEmpty()) { // Iterate through the temporary stack
	            input.add(tempStack.pop()); // Add an element from the temp stack back to the input queue
	        }
	    }
	}


