package Week_10;
	import org.junit.jupiter.api.Test;

	import static org.junit.jupiter.api.Assertions.*;

import java.util.LinkedList;
import java.util.Queue;
	public class MyFIFOAppTest {

	    @Test
	    public void testStutter() {
	        Queue<Integer> input = new LinkedList<>();
	        input.add(1);
	        input.add(2);
	        input.add(3);

	        MyFIFO_App.stutter(input);

	        assertEquals(6, input.size());
	        assertEquals(1, input.poll());
	        assertEquals(1, input.poll());
	        assertEquals(2, input.poll());
	        assertEquals(2, input.poll());
	        assertEquals(3, input.poll());
	        assertEquals(3, input.poll());
	    }

	    @Test
	    public void testMirror() {
	        Queue<String> input = new LinkedList<>();
	        input.add("a");
	        input.add("b");
	        input.add("c");

	        MyFIFO_App.mirror(input);

	        assertEquals(6, input.size());
	        assertEquals("a", input.poll());
	        assertEquals("b", input.poll());
	        assertEquals("c", input.poll());
	        assertEquals("c", input.poll());
	        assertEquals("b", input.poll());
	        assertEquals("a", input.poll());
	    }
	
}
