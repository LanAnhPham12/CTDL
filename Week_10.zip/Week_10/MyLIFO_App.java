package Week_10;

import java.util.Stack;

public class MyLIFO_App {
	public static <E> void reverse(E[] array) {
		Stack<E> stack = new Stack<E>();
		for (E element : array)
			stack.push(element);
		int i = 0;
		while (!stack.isEmpty())
			array[i] = stack.pop();
		i++;
	}

//method checks the correctness of the given input
	// i.e. ()(())[]{(())} ==> true, ){[]}() ==> false
	public static boolean isCorrect(String input) {
		Stack<Character> stack = new Stack<>();
		for (Character character : input.toCharArray())
			if (character == '(' || character == '[' || character == '{') {
				stack.push(character);
			} else if (character == ')') {
				if (stack.isEmpty() || stack.pop() != '(') {
					return false;
				}
			} else if (character == ']') {
				if (stack.isEmpty() || stack.pop() != '[') {
					return false;
				}
			} else if (character == '}') {
				if (stack.isEmpty() || stack.pop() != '}') {
					return false;
				}
			}
		return stack.isEmpty();

	}
	// method evaluates the value of an expression 51 + (54 *(3+2)) = 321
/**
 * public static int evaluateExpression (String expression) {
 * Stack<Integer> stack = new Stack<Integer>();
	for(Character character : expression.toCharArray())
		if (character == )
		
	return 0;
	
 */
public static String inSentBlanks (String input) {
	String re = " ";
for (int i = 0; i < input.length(); i++) {
		if (input.charAt(i) == '+' || input.charAt(i)== '-' || input.charAt(i)== '*' || input.charAt(i)== '/' || input.charAt(i)== ')'|| input.charAt(i)== '(') {
			re = re + " " + input.charAt(i) + " ";
			
		}else {
			re = re + input.charAt(i);
		}
		
	}
return re;
}
//method stutter that accepts a queue of integers as
public static void main(String[] args) {
	
}
}
