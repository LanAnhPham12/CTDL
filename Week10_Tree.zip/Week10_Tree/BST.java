package Week10_Tree;

import java.util.Collection;

public class BST <E extends Comparable<E>>{
private BNode<E> root;
public BST () {
	this.root = null;
}
//add element 
public void add (E e) {
	if (root == null) {
		 root  = new BNode(e);
	}else {
		 root.add(e);
	}
}

}

