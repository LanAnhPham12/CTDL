package Week10_Tree;

import java.util.ArrayList;
import java.util.List;

public class BNode<E extends Comparable<E>>{
	private E data;
	private BNode<E> left;
	private BNode<E> right;
	public BNode(E data) {
	this.data = data;
	this.left = null;
	this.right = null;
	}
	public BNode(E data, BNode<E> left, BNode<E> right) {
	this.data = data;
	this.left = left;
	this.right = right;
	}
	public int depth(E node) {
		BNode<E> root = null;
		BNode<E> currentNode = root;
		int depth = 0;
		while (currentNode != null) {
			if (currentNode.data.equals(node)) {
				return depth;
			}

			if (node.compareTo(currentNode.data) < 0) {
				currentNode = currentNode.left;
			} else {
				currentNode = currentNode.right;
			}

			depth++;
		}

		return -1;
	}
	public boolean contains (E e) {
		 int  comp = e.compareTo(data);
		 if ( comp == 0)
			 return true;
		 else if (comp < 0) return (left == null)? false;
		 left.contains(e);
		 else if (comp > 0) { return ( right == null)? false;
			right.contains(e);
		}
	}
	public List<E> descentdants (E e){
		int comp = data.compareTo(e);
		List<E> re = new ArrayList<>();
		if ( comp == 0) {
			if (left != null) {
				re.add(left.data);
				re.addAll(left.descentdants(e));
			}
			if (right != null) {
				re.add(right.data);
				re.addAll(right.descentdants(e));
			}
		}
		return re;
	}
	public List <E> ancestors (E e){
		int comp = e.compareTo(data);
		List<E> re = new ArrayList<>();
		if ( left != null) {
			
		}
	}
	}



