package Week_5;

import java.util.Arrays;
import java.util.Iterator;

public class BasicProblems {
//add 2 matrices
	public static int[][] add(int[][] a, int[][] b) {
		// neu row a khong bang row b or col a khong bang col b thi tung ra ngoai le
		if (a.length != b.length || a[0].length != b[0].length)
			throw new IllegalArgumentException("Two array 2d must same length");
		int[][] result = new int[a.length][a[0].length];
		for (int i = 0; i < result.length; i++) {
			for (int j = 0; j < result[0].length; j++) {
				result[i][j] = a[i][j] + b[i][j];
			}
		}
		return result;
	}

	// subtract 2 matrices
	public static int[][] subtract(int[][] a, int[][] b) {
		if (a.length != b.length || a[0].length != b[0].length)
			throw new IllegalArgumentException("Two array 2d must same length");
		int[][] rs = new int[a.length][a[0].length];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[0].length; j++) {
				rs[i][i] = a[i][j] - b[i][j];
			}
		}prnt(rs);
		return rs;

	}

//multiply 2 matrices
	public static int[][] multiply(int[][] a, int[][] b) {
		if (a.length != b[0].length) {
			throw new IllegalArgumentException(
					"The number of col in the first matrix must be euqal to the number of rows in the second matrix.");
		}
		int[][] rsl = new int[a.length][a[0].length];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < b[0].length; j++) {
				for (int k = 0; k < a[0].length; k++) {
					rsl[i][j] += a[i][k] * b[k][j];
				}
			}
		}prnt(rsl);
		return rsl;

	}

	// transpose a matrix
	public static int[][] transpose(int[][] a) {
		int[][] resultTranspose = new int[a[0].length][a.length];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				resultTranspose[j][i] = a[i][j];
			}

		}
		prnt(resultTranspose);
		return resultTranspose;
	}

	static void prnt(int[][] arr) {
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr[i].length; j++) {
				System.out.print(arr[i][j] + "\t");

			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		int[][] a = { { 7, 2 }, { 5, 3 } };
		int[][] c = { { 7, 2 }, { 5, 3 }, { 6, 8 } };
		int[][] b = { { 2, 1 }, { 3, 1 } };
		int[][] result = add(a, b);
		int[][] rs = subtract(a, b);
		int[][] rsl = multiply(a, b);
		// int[][] re
		for (int i = 0; i < result.length; i++) {
			for (int j = 0; j < result[0].length; j++) {
				System.out.print(result[i][j] + " ");
				// System.out.println(rs[i][j] + " ");
			//	 System.out.println(rsl);
			}System.out.println();
		}
		Arrays.toString(transpose(c));

	}
}