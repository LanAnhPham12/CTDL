package Week_5;

public class TicTacToeGame {
	private static final char EMPTY = ' ';
	private char[][] board;

	public TicTacToeGame(char[][] board) {
		super();
		this.board = board;
	}

	public boolean checkRows() {
		for (int row = 0; row < board.length; row++) {
			// kiem tra tat ca cac phan tu trong hang co giong nhau hay khong
			char marker = board[row][0];
			if (marker == EMPTY) {
				continue;
			}
			for (int col = 1; col < board[row].length; col++) {
				if (board[row][col] != marker) {
					break;
				}
			}
			return true;
		}
		return false;
	}

	public boolean checkColumns() {
		for (int col = 0; col < board[0].length; col++) {
			//kiem tra tat ca phan tu trong cot co giong nhau hay khon
			char marker = board[0][col];
			if (marker == EMPTY) {
				continue;
			}
			for (int row = 1; row < board.length; row++) {
				if (board[row][col] != marker) {
					break;
				}
			}
			return true;
		}
		return false;
	}

	public boolean checkDiagonals() {
		// Check top-left to bottom-right diagonal
		char marker = board[0][0];
		if (marker != EMPTY) {
			for (int i = 1; i < board.length; i++) {
				if (board[i][i] != marker) {
					break;
				}
			}

			// If we reach here, it means all elements in the top-left to bottom-right
			// diagonal are the same
			return true;
		}

		// Check bottom-left to top-right diagonal
		marker = board[board.length - 1][0];
		if (marker != EMPTY) {
			for (int i = board.length - 1; i >= 0; i--) {
				if (board[i][i] != marker) {
					break;
				}
			}

			// If we reach here, it means all elements in the bottom-left to top-right
			// diagonal are the same
			return true;
		}

		// If we reach here, it means neither diagonal has all the same elements
		return false;
	}

	public boolean hasWon() {
		return checkRows() || checkColumns() || checkDiagonals();
	}
	  public static void main(String[] args) {
	        // Create a new TicTacToeGame object
	        char[][] board = new char[][] {
	            { '_', '_', '_' },
	            { '_', '_', '_' },
	            { '_', '_', '_' }
	        };
	        TicTacToeGame game = new TicTacToeGame(board);

	        // Check if the player has won
	        if (game.hasWon()) {
	            System.out.println("Player X has won!");
	        } else {
	            System.out.println("The game is not over yet.");
	        }
	    }
	}


