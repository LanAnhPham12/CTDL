package Week_8;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class TextAnalyzer {
    // <word, its positions>
    private static Map<String, ArrayList<Integer>> map = new HashMap<String, ArrayList<Integer>>();

    // load words in the text file given by fileName and store into map by using add
    // method in Task 2.1.
    // Using BufferedReader reffered in file TextFileUtils.java
    public static void readText(String fileName) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line = null;
        int position = 0;
        while (true) {
            line = reader.readLine();

            if (line == null)
                break;

            StringTokenizer tokens = new StringTokenizer(line, " ");

            while (tokens.hasMoreTokens()) {
                String word = tokens.nextToken();
                addWord(word, position);
                position++;
            }
        }
        reader.close();
    }

    private static void addWord(String word, int position) {
        ArrayList<Integer> positions = map.get(word);
        if (positions == null) {
            positions = new ArrayList<>();
        }
        positions.add(position);
        map.put(word, positions);
    }

    // This method should display the words of the text file along with the
    // positions of each word, one word per line, in alphabetical order
    public void displayWords() {
        Set<String> words = map.keySet();
        List<String> sortedWords = new ArrayList<>(words);
        Collections.sort(sortedWords);

        for (String word : sortedWords) {
            ArrayList<Integer> positions = map.get(word);
            System.out.println(word + ": " + positions);
        }
    }

    // This method will display the content of the text file stored in the map
    public void displayText() {
        Set<String> words = map.keySet();
        List<String> sortedWords = new ArrayList<>(words);
        Collections.sort(sortedWords);

        for (String word : sortedWords) {
            System.out.print(word + " ");
        }
    }

    // This method will return the word that occurs most frequently in the text file
    public String mostFrequentWord() {
        int maxCount = 0;
        String mostFrequentWord = null;

        for (String word : map.keySet()) {
            ArrayList<Integer> positions = map.get(word);
            int count = positions.size();

            if (count > maxCount) {
                maxCount = count;
                mostFrequentWord = word;
            }
        }

        return mostFrequentWord;
    }
}
