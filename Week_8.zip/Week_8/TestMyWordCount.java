package Week_8;

import java.io.FileNotFoundException;

public class TestMyWordCount {
	public static void main(String[] args) throws FileNotFoundException {
		MyWordCountApp app = new MyWordCountApp();
		app.loadData();
		System.out.println( "count: " +app.countUnique());
		System.out.println();
	}
}
