package Week_9;

import java.util.ArrayList;
import java.util.List;

public class Magazine extends Book{
private String name;

public Magazine(String title, int page, int year, String author, double price, String name) {
	super(title, page, year, author, price);
	this.name = name;
}
public boolean containsMagazine(String title) {
    for (Book book : books) {
        if (book.getType().equals("Tạp chí") && book.getTitle().equals(title)) {
            return true;
        }
    }
    return false;
}
public List<Magazine> getMagazinesByYear(int year) {
    List<Magazine> magazines = new ArrayList<>();
    for (Book book : books) {
        if (book.getType().equals("Tạp chí") && book.year == year) {
            magazines.add((Magazine) book);
        }
    }
    return magazines;
}

}
