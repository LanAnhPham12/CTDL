package Week_9;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Faculty {
private String name;
private String address;
private List<Course> courses;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public List<Course> getCourses() {
	return courses;
}
public void setCourses(List<Course> courses) {
	this.courses = courses;
}
public Faculty(String name, String address, List<Course> courses) {
	super();
	this.name = name;
	this.address = address;
	this.courses = courses;
}
public Course getMaxPracticalCourse() {
    Course maxCourse = courses.stream().filter(course -> course.getType().equals("Thực hành")).findFirst().get();
    for (Course course : courses) {
        if (course.getType().equals("Thực hành") && course.getStudents().size() > maxCourse.getStudents().size()) {
            maxCourse = course;
        }
    }
    return maxCourse;
}
public Map<Integer, List<Student>> groupStudentsByYear() {
    Map<Integer, List<Student>> studentsByYear = new HashMap<>();
    for (Student student : students) {
        int year = student.getYear();
        List<Student> studentsInYear = studentsByYear.get(year);
        if (studentsInYear == null) {
            studentsInYear = new ArrayList<>();
            studentsByYear.put(year, studentsInYear);
        }
        studentsInYear.add(student);
    }
    return studentsByYear;
}
public Set<Course> filterCourses(String type) {
    return courses.stream().filter(course -> course.getType().equals(type)).collect(Collectors.toSet());
}

}
