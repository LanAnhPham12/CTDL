package Week_9;

import javax.sound.sampled.Clip;

public class ReferenceBook extends Book{
private String field;//linh vuc
private int chap;//chuong
public ReferenceBook(String title, int page, int year, String author, double price, String field, int chap) {
	super(title, page, year, author, price);
	this.field = field;
	this.chap = chap;
}
public Book findBookWithMostPagesChapter() {
    int maxPages = 0;
    Book bookWithMostPages = null;
    for (Book book : books) {
        int totalPages = 0;
        for (Chap chap : book.chap) {
            totalPages += chap.pages;
        }
        if (totalPages > maxPages) {
            maxPages = totalPages;
            bookWithMostPages = book;
        }
    }
    return bookWithMostPages;
}

}
