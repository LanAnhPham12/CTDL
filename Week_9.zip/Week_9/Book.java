package Week_9;

import java.util.Comparator;
import java.util.Date;
import java.util.Map;

public abstract class Book {
	protected String title;
	protected int page;
	protected int year;
	protected String author;
	protected double price;

	public Book(String title, int page, int year, String author, double price) {
		super();
		this.title = title;
		this.page = page;
		this.year = year;
		this.author = author;
		this.price = price;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getType() {
		return "Sách tham khảo";
	}

	public boolean isOldMagazine() {
		return this.getType().equals("Tạp chí") && (new Date().getYear() - this.year) >= 10;
	}

	public boolean isSameTypeAndAuthor(Book book) {
		return this.getType().equals(book.getType()) && this.author.equals(book.getAuthor());
	}

//tong tien cua tat ca cac an pham trong nha sach
	public double getTotalMoney() {
		double totalMoney = 0;
		for (Book book : books) {
			totalMoney += book.getPrice();

		}
		return totalMoney;
	}

	public void sort() {
		Book.sort(Comparator.comparing(Book::getTitle).thenComparing(Book::year, Comparator.reverseOrder()));
	}

	public Map<Integer, Integer> statistic() {
		Map<Integer, Integer> statistics = new HashMap<>();
		for (Book book : books) {
			int year = book.year;
			if (!statistics.containsKey(year)) {
				statistics.put(year, 1);
			} else {
				statistics.put(year, statistics);

			}
		}
	}
}